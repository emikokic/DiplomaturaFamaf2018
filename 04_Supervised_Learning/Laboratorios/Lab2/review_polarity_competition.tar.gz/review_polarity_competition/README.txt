This dataset contains 1,070 DVDs reviews. These are labelled as positive/negative reviews (in the reviews_sentoken directory). Additionally, there are 500 reviews that are not labelled (in the test_reviews_sentoken directory).

You may see that the number of samples for testing is too large. Therefore, it may be a good idea to augment the training data.

When the competition ends, will will let you know how to obtain the dataset (avoid googling it, please :P )